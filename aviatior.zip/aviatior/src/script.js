// Game Variables
let users = JSON.parse(localStorage.getItem("aviator_users")) || {};
let currentUser = null;
let balance = 1000;
let gameInterval;
let currentMultiplier = 1;
let currentBet = 0;

// DOM Elements
const authSection = document.getElementById("auth-section");
const gameSection = document.getElementById("game-section");
const loginBtn = document.getElementById("login-btn");
const registerBtn = document.getElementById("register-btn");
const startBtn = document.getElementById("start-btn");
const cashoutBtn = document.getElementById("cashout-btn");
const logoutBtn = document.getElementById("logout-btn");
const betAmountInput = document.getElementById("bet-amount");
const betDisplay = document.getElementById("bet-display");
const plane = document.getElementById("plane");
const multiplierDisplay = document.getElementById("multiplier");

// Event Listeners
loginBtn.addEventListener("click", login);
registerBtn.addEventListener("click", register);
startBtn.addEventListener("click", startGame);
cashoutBtn.addEventListener("click", cashout);
logoutBtn.addEventListener("click", logout);
betAmountInput.addEventListener("input", updateBetDisplay);

// Update bet amount display
function updateBetDisplay() {
    currentBet = parseInt(betAmountInput.value);
    betDisplay.textContent = currentBet;
}

// Login Function
function login() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (!username || !password) {
        showMessage("Username and password required!");
        return;
    }

    if (!users[username]) {
        showMessage("User not found!");
        return;
    }

    if (users[username].password !== password) {
        showMessage("Wrong password!");
        return;
    }

    // Login successful
    currentUser = username;
    balance = users[username].balance;
    showGameSection();
}

// Register Function
function register() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username.length < 4) {
        showMessage("Username must be 4+ characters");
        return;
    }

    if (password.length < 6) {
        showMessage("Password must be 6+ characters");
        return;
    }

    if (users[username]) {
        showMessage("Username already exists");
        return;
    }

    // Register user
    users[username] = {
        password: password,
        balance: 1000
    };
    localStorage.setItem("aviator_users", JSON.stringify(users));
    showMessage("Registration successful! Please login.");
}

// Start Game
function startGame() {
    if (currentBet > balance) {
        showMessage("Not enough balance!");
        return;
    }

    if (currentBet < 10) {
        showMessage("Minimum bet is ₹10");
        return;
    }

    // Deduct bet amount
    balance -= currentBet;
    updateBalance();

    // Reset game state
    currentMultiplier = 1;
    plane.style.bottom = "50%";
    multiplierDisplay.textContent = "1.00x";

    // Disable start button during game
    startBtn.disabled = true;
    cashoutBtn.classList.remove("hidden");

    // Game loop
    gameInterval = setInterval(() => {
        currentMultiplier += 0.05;
        multiplierDisplay.textContent = currentMultiplier.toFixed(2) + "x";

        // Move plane up
        const currentBottom = parseInt(plane.style.bottom) || 50;
        plane.style.bottom = (currentBottom - 1) + "%";

        // Random crash between 1.5x to 20x
        if (currentMultiplier >= Math.random() * 18 + 1.5) {
            endGame(false);
        }
    }, 100);
}

// Cashout manually
function cashout() {
    endGame(true);
}

// End game (win or crash)
function endGame(isManualCashout) {
    clearInterval(gameInterval);

    const winAmount = Math.floor(currentBet * currentMultiplier);
    balance += winAmount;
    updateBalance();

    // Save user data
    if (currentUser) {
        users[currentUser].balance = balance;
        localStorage.setItem("aviator_users", JSON.stringify(users));
    }

    // Show result message
    const message = isManualCashout 
        ? `Cashed out at ${currentMultiplier.toFixed(2)}x! Won ₹${winAmount}`
        : `Crashed at ${currentMultiplier.toFixed(2)}x! Lost ₹${currentBet}`;
    
    alert(message);

    // Reset UI
    startBtn.disabled = false;
    cashoutBtn.classList.add("hidden");
}

// Show game section after login
function showGameSection() {
    authSection.classList.add("hidden");
    gameSection.classList.remove("hidden");
    updateBalance();
    updateBetDisplay();
}

// Logout
function logout() {
    currentUser = null;
    gameSection.classList.add("hidden");
    authSection.classList.remove("hidden");
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
}

// Helper functions
function updateBalance() {
    document.getElementById("balance").textContent = balance;
}

function showMessage(msg) {
    const msgElement = document.getElementById("auth-message");
    msgElement.textContent = msg;
    setTimeout(() => msgElement.textContent = "", 3000);
}